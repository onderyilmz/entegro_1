from django.apps import AppConfig


class SolaredgeConfig(AppConfig):
    name = 'solaredge'
