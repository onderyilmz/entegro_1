from django.apps import AppConfig


class Department1Config(AppConfig):
    name = 'department_1'
